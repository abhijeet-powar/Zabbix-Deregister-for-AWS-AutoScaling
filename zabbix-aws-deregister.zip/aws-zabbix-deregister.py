
# ################################# V3 #################################################################################################
import requests
import json
import os

def get_host_id(zabbix_url, zabbix_token, instance_id):
    # Construct a search query using the instance ID as the alias in the inventory
    api_url = f"{zabbix_url}/zabbix/api_jsonrpc.php"
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {zabbix_token}'
    }

    search_inventory_payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": ["hostid"],
            "selectInventory": ["alias"],
            "searchInventory": {
                "alias": instance_id
            }
        },
        "id": 1
    }

    response = requests.post(api_url, data=json.dumps(search_inventory_payload), headers=headers, )
    print(f"{response} --- response displayed")
    result = response.json()
    print(f"{result} --- response displayed")
    if 'result' in result and result['result']:
        return result['result'][0]['hostid']
    else:
        return None

def deregister_host(zabbix_url, zabbix_token, instance_id):
    # Retrieve the Zabbix host ID using the provided EC2 instance ID
    host_id = get_host_id(zabbix_url, zabbix_token, instance_id)
    print(f"{host_id} --- hostid displayed")
    print(f"{instance_id} --- instance_id displayed")
    print(f"{zabbix_token} --- zabbix_token displayed")
    if host_id:
        api_url = f"{zabbix_url}/zabbix/api_jsonrpc.php"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {zabbix_token}'
        }

        # Proceed to delete the Zabbix host using the retrieved host ID
        delete_payload = {
            "jsonrpc": "2.0",
            "method": "host.delete",
            "params": [host_id],
            "id": 1
        }

        response = requests.post(api_url, data=json.dumps(delete_payload), headers=headers)
        result = response.json()

        if 'result' in result:
            print(f"Host with ID {host_id} deregistered successfully.")
        else:
            print(f"Failed to deregister host with ID {host_id}. Error: {result.get('error')}")
    else:
        print(f"No host found for instance ID {instance_id}.")

def lambda_handler(event, context):
    zabbix_url = os.environ['ZABBIX_URL']
    zabbix_token = os.environ['ZABBIX_ACCESS_TOKEN']
    
    print(f"{event} --- event displayed")
   
    instance_id = json.loads(json.loads(json.dumps(event))['Records'][0]['Sns']['Message'])['detail']['instance-id']
   
    print(f"{instance_id} --- instance_id displayed---1")
    # Delete the Zabbix host based on the EC2 instance ID
    deregister_host(zabbix_url, zabbix_token, instance_id)



